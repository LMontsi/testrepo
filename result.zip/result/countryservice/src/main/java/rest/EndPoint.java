package rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

import static org.springframework.web.bind.annotation.RequestMethod.GET;

@RestController
public class EndPoint {


    @Autowired
    DetermineCountry dc;

    @RequestMapping(value ="/lookup/{ip}", method = GET)
    public ResponseEntity<String> lookup(@PathVariable("ip") String ip)
    {

        String contrycode = null;
        try {
            contrycode=dc.getCountry(ip);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            String error = (e.getMessage());
            return   ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
        }
        return new ResponseEntity<>(contrycode, HttpStatus.OK);
    }
}