package rest;

import java.io.IOException;

import com.maxmind.geoip.LookupService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class DetermineCountry {
    private LookupService lookUpService = null;

    @Value("${dbfile}")
    private String dbfile;

    public LookupService getLookUpService() throws IOException
    {
        if(lookUpService!=null)
        {
            return lookUpService;
        }
        else
        {
            if(dbfile==null)
            {
                throw new RuntimeException("dbfile not found");
            }
            lookUpService = new LookupService(dbfile,LookupService.GEOIP_MEMORY_CACHE);
            return lookUpService;
        }
    }

    public String getCountry(String ipAddress)
    {
        String country="No Country Found";
        LookupService localLookUp=null;
        try {
            localLookUp=getLookUpService();
            country=localLookUp.getCountry(ipAddress).getCode();
        } catch (IOException e) {
            e.printStackTrace();
        }
        finally
        {
            if(localLookUp!=null)
                localLookUp.close();
        }
        return country;
    }
}
