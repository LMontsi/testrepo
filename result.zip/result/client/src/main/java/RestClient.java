import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.MediaType;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class RestClient {

    static Client client = ClientBuilder.newClient();



    public static void main(String [] args)
    {
        System.out.println("======================================");
        System.out.println(("COUNTRY CODES"));
        if(args.length<1)
        {
            System.out.println("provide test file as argument");
            System.exit(1);
        }
       SortedMap<String,String>countryIP= getRecordFromFile(args[0]);
        Set s = countryIP.entrySet();
        Iterator i = s.iterator();


        while (i.hasNext())
        {
            Map.Entry m = (Map.Entry)i.next();

           String key = (String)m.getKey();
            String value = (String)m.getValue();

            System.out.println("Sorted value : " + key +
                    "  IP : " + value+" Country Code: "+retrieveCustomer(value));
        }
    }

    public static String retrieveCustomer(String id) {
        String countryCode = client.target("http://localhost:8080/lookup/")
                        .path(id)
                        .request(MediaType.TEXT_PLAIN)//doesnt matter
                        .get(String.class);

        return countryCode;
    }

    public static SortedMap<String,String> getRecordFromFile(String csvFile)
    {
        SortedMap<String, String> sm = new TreeMap<String, String>();

        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = ",";

        try {

            br = new BufferedReader(new FileReader(csvFile));
            while ((line = br.readLine()) != null) {

                // use comma as separator
                String[] country = line.split(cvsSplitBy);


                sm.put(country[1],country[0]);

            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return sm;
    }
}
